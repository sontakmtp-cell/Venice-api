# Cấu hình mô hình trong Codex

Plugin dùng model-policy.json làm bảng điều phối; Codex/ChatGPT không tự nạp file
này. Khi có công cụ spawn cho phép override, trưởng nhóm truyền model và effort
theo policy. Chọn GPT-6.1 Sol cho cuộc hội thoại trưởng nhóm nếu host cho phép.

Tùy chọn cho Codex có hỗ trợ cấu hình agent TOML:

1. Trong dự án bạn muốn dùng bộ chuyên gia, kiểm tra cấu hình `.codex/config.toml`
   và chính sách tin cậy/quản trị hiện có. Không ghi đè file đang có.
2. Chép các file `config/codex/agents/*.toml` của gói vào `.codex/agents/` của dự án,
   giữ nguyên tên. Nếu file đích đã có, đối chiếu và hợp nhất có chủ đích.
3. Hợp nhất các khóa/bảng trong `config/codex/config.toml.example` vào cấu hình
   của dự án. `config_file` tính tương đối từ file config định nghĩa nó, nên
   `agents/content-writer.toml` sẽ trỏ tới `.codex/agents/content-writer.toml`.
4. Các tên role native dùng dấu gạch dưới; chọn đúng role qua công cụ spawn có
   hỗ trợ role của host. Plugin điều phối cũng hỗ trợ spawn general worker với
   brief đầy đủ khi host không có agent_type đăng ký.
5. Mở lại phiên theo cơ chế của host, kiểm tra role/model thực sự được chọn bằng
   kết quả runtime. Schema hợp lệ không chứng minh tài khoản được cấp mô hình.

Cấu hình mẫu đã đối chiếu schema chính thức của openai/codex tại thời điểm chuyển
đổi. Phiên bản cũ có thể khác; kiểm tra schema của phiên bản cài đặt trước khi dùng.
Không có script tự chỉnh cấu hình toàn cục hoặc bỏ qua giới hạn của host.
ChatGPT không hỗ trợ TOML này: dùng policy qua native tool khi có; nếu không,
chạy tuần tự trên model hiện tại và báo rõ giới hạn.
