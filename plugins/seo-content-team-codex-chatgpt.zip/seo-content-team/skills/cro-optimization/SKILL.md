---
name: cro-optimization
description: "Use conversion optimization frameworks for landing pages, forms, signup, pricing, popups and paywalls."
---


# Conversion optimization

Read [the complete source framework](../seo-content-team/references/original-skills/cro-optimization/source.md)
and [runtime adaptations](../seo-content-team/references/runtime.md).
Choose the relevant context: landing page, form, signup flow, pricing page,
popup or paywall. Evaluate value clarity, cognitive load, CTA, friction, trust,
objections and decision journey. Use ethical persuasion and genuine claims.
Return a motivation profile, persuasion audit, exact proposed copy changes,
prioritized experiments and implementation locations. Predicted lift is a
hypothesis, not observed performance. Include baseline/metric, audience,
allocation, guardrails and a stopping rule for actionable A/B tests where inputs
support them; mark missing analytics clearly. This is a methodology skill, not
an analytics connection. Optional provider evidence follows integrations.md.
