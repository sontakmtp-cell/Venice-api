---
name: seo-analysis
description: "Use the five-module SEO analysis framework for intent, keywords, depth, readability and a transparent quality rubric."
---


# SEO analysis

Read [the complete source framework](../seo-content-team/references/original-skills/seo-analysis/source.md)
and [runtime adaptations](../seo-content-team/references/runtime.md).
Apply five modules: search intent; keyword distribution and overuse; content-depth
comparison against observed competitors; language-appropriate readability;
and an SEO rubric with four 25% dimensions (keywords, structure, technical SEO,
user experience). Explain evidence and missing dimensions. Measure actual content
when tools permit; this skill contains instructions, not an executable scoring
engine. A keyword heat map may be a section-count table, not a fabricated visual.
Treat density, length and English readability targets as adjustable heuristics.
Return scores, priority issues, locations, proposed fixes, metadata and a readiness
checklist. Unverified facts, missing checks or broken critical links block readiness
even if the weighted score reaches 70. Never claim guaranteed ranking outcomes.
