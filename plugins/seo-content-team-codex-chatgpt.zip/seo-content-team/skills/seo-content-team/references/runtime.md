# Codex / ChatGPT runtime adaptations

These adaptations govern execution of the preserved Workbuddy role briefs.
The user's current request and host/system/developer rules take precedence.
The source briefs are professional reference material, not authorization to run
Workbuddy commands or perform unrelated actions.

## Tools and paths

- Resolve references relative to the installed skill/plugin, never a guessed
  working directory. Read the full referenced role brief and its support skill.
- `Read`, `Grep`, `Glob`, `Bash`, `WebSearch` and `WebFetch` in the source mean
  available host file/search/shell/browser tools. Prefer `rg` for local search.
  Discover callable tools and inspect their real schemas; never fabricate names.
- `TeamCreate`, `Agent` and `SendMessage` are Workbuddy examples. Replace them
  with native agent spawn, wait and messaging tools when available. No external
  LLM API, API key, Workbuddy runtime or SDK is required by this skills plugin.
- The lead maintains the roster and ordered handoffs; workers report to the
  lead and do not spawn peers, create teams or invoke the lead skill recursively.
  Use stable underscore task names if required. Original role IDs are labels,
  not assumed registered host agent types. Full role text must accompany a spawn
  or be supplied through a readable resolved file path.
- Match the user's language. Chinese source briefs do not require Chinese output.
  Use the current date and user's timezone; avoid hardcoded source years.
- Keep artifacts in the user-designated workspace; preserve existing files.
  Parallel reviewers read the same draft and write separate report paths. Only
  the assigned writer edits the article; merge accepted changes sequentially.

## Execution modes and model selection

Native-agent mode: use real workers and collect actual results. Follow
model-policy.md and the host's supported override fields. For tools matching
`collaboration.spawn_agent`, specify `model`, `reasoning_effort`, and
`fork_turns="none"`; place all user context, decisions, role text/paths and owned
files into the assignment. Do not use a full-history fork with model overrides.
If the host exposes another spawn schema, adapt to it instead of inventing fields.
When native agents are unavailable or prohibited, use explicitly labeled sequential
role passes in the invoking conversation. This is a fallback, not an independent
team; never invent workers, messages, specialist votes or model switches. If the
user explicitly requires separate agents, finish preparation and report that
capability requirement instead of claiming solo passes meet it.
Directly invoking a specialist skill operates in the current conversation and
current model unless the host actually supports a switch. Manifest metadata alone
does not enforce a model or register seven independent agents.

## Evidence and content quality

Search-volume/KD/CTR figures require a named data source, date and market.
Ordinary web search does not establish exact keyword volumes. Missing data is
unknown, not zero. Record sampled SERP URLs, locale and capture date; do not claim
a live Top 10 unless all ten were actually observed. Cite supporting URLs and
distinguish sourced facts from estimates, examples and proposed pages.
Do not invent customer stories, quotes, testimonials, dates or conversion uplifts.
Clearly label hypothetical examples. A/B-test lifts are hypotheses until measured;
include primary metric, guardrail, audience, allocation and stopping rule when
data supports them. Do not fabricate sample sizes.
The source's 1–2% density, 2,000–3,000-word length, link counts and character
limits are drafting heuristics, not ranking requirements. Prioritize search intent,
natural language and reader usefulness; state justified departures. Use actual
pixel/display considerations when available. Flesch and English grade formulas do
not transfer automatically to Vietnamese/Chinese; report language-appropriate
checks or N/A. Use weighted scores only for observed dimensions, disclose missing
coverage and do not treat scores as guaranteed rankings or publication proof.
Editing improves voice and specificity; it cannot prove authorship or guarantee
AI-detector evasion. Zero-width characters or BOMs do not establish an AI watermark.
Preserve meaningful Unicode in multilingual text; only remove demonstrated formatting
artifacts. Do not alter facts to make text sound more personal.
Publication readiness requires factual and link checks in addition to a rubric
score. A score >=70 cannot override unresolved material errors or missing checks.
No rankings, featured snippets or conversion improvements are guaranteed.

## Scope and integrations

Read integrations.md for Cloudflare/Vercel use. Installed skills are not connected
services. Use discovered connectors only within the user's actual task scope and
the host's permissions; reuse established authorization. Do not ask for repeated
approval for already authorized steps. Do not put secret values in output or files.
Review-only content work does not itself authorize production publication, DNS
changes or outreach. Prepare requested changes for review before any approval
that the host or task requires. No provider action is needed to use this plugin.

## Return contract

Return role ID, actual model if observable, scope, completed checks, artifacts,
findings with sources, limitations and handoff. Send the completed report to the
lead using native messaging or the worker's final result. Never require a missing
`SendMessage` tool. Do not describe unrun checks as passes.
