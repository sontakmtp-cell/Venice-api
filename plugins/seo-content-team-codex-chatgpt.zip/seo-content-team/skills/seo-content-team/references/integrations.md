# Optional Cloudflare and Vercel integrations

The user permits specialists to use these integrations when their task needs them.
This permission authorizes appropriate tool use; installation, authentication,
resource selection and host permissions still determine what is executable.

- [Cloudflare](plugin://app-6a99ceead2c481919fb44845267235c4@openai-curated-remote)
- [Vercel](plugin://vercel@openai-curated-remote)

These are the plugin references supplied by the user, not guessed MCP server IDs,
endpoints or an automatic dependency installer. Use the host's supported plugin
installation and connection flow. Do not package or recreate those providers.
When a plugin is absent, use available local/web tools and report the unavailable
capability only when it affects the requested work. Credentials go through the
provider's connection/settings flow, never chat or the plugin archive.

| Specialist | Cloudflare, if exposed by its installed connector | Vercel, if exposed by its installed connector |
|---|---|---|
| Lead | Coordinate target/account selection and approved changes | Coordinate project/deployment verification |
| Keyword researcher | Use relevant traffic analytics as supplementary evidence | Use relevant site analytics as supplementary evidence |
| Writer | Inspect an authorized published/preview page for context | Inspect an authorized preview for content context |
| SEO optimizer | Inspect cache, redirects, response headers, robots/sitemap and route behavior | Inspect deployment logs, build status, metadata and preview behavior |
| Editor | Review authorized page content | Review authorized preview content |
| CRO analyst | Use relevant aggregate traffic/performance evidence | Use relevant aggregate analytics and preview behavior |
| Link strategist | Inspect redirects, canonical paths and broken links | Check preview routes, internal links and deployment paths |

Always discover the actual callable tools and inspect schemas first. Some
connectors may expose only a subset of these capabilities. Do not claim that
Cloudflare/Vercel traffic analytics contain Google Search Console queries or
keyword volumes. Identify the correct project, account and domain from task
context before operating. Inspect read-only status/logs for a diagnosis, then
make only the changes authorized by the user's publishing/deployment request.
Permission to use a connector is not a blanket request to publish to production,
replace DNS, purge caches, alter billing or contact third parties. Avoid redundant
confirmation within an already authorized workflow. If explicit approval is
required, prepare the concrete diff/preview and relevant checks first.

For requested deployments, verify the actual build, target environment and URLs,
then read back the deployment result and check representative pages/links. Record
what was executed and what remains unverified. Do not fabricate a preview URL.
