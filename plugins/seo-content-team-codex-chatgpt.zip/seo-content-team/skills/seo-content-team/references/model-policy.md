# Model policy

These are the user's requested default models for this package, not aliases for
unavailable models. Runtime identifiers are `gpt-6-luna` and `gpt-6.1-sol`.
The lead remains in the invoking conversation: select GPT-6.1 Sol in the host UI
when available. Do not spawn a duplicate lead solely to force a model change.

| Role | Model | Reasoning effort | Rationale |
|---|---|---|---|
| seo-content-team-lead | `gpt-6.1-sol` | `high` | Điều phối nhiều giai đoạn, xử lý xung đột và kiểm tra chất lượng. |
| keyword-researcher | `gpt-6.1-sol` | `high` | Tổng hợp nguồn, phân loại ý định và đối chiếu đối thủ. |
| content-writer | `gpt-6.1-sol` | `medium` | Giữ mạch bài dài, tính chính xác và giọng thương hiệu. |
| seo-optimizer | `gpt-6-luna` | `high` | Kiểm tra có tiêu chí rõ: cấu trúc, metadata, từ khóa và schema. |
| content-editor | `gpt-6-luna` | `high` | Biên tập có brief, sửa cách diễn đạt và giữ nguyên ý nghĩa. |
| cro-analyst | `gpt-6.1-sol` | `high` | Thiết kế giả thuyết, phân tích funnel và tránh diễn giải sai dữ liệu. |
| link-strategist | `gpt-6-luna` | `high` | Ánh xạ URL, anchor text và liên kết pillar/spoke theo đầu vào đã xác minh. |


Escalate a Luna assignment to `gpt-6.1-sol` / `high` when it needs technical SEO
diagnosis across application code/redirects, a large link graph with conflicting
signals, specialist factual review, or extensive multilingual brand rewrites.
Record the reason; only dispatch the affected task again and avoid overlapping
edits. If Sol is unavailable, report the limitation; do not silently substitute
another model and claim the selected one was used.

Use these selections in native spawn arguments when the tool supports them.
`config/model-policy.json` is package data for the orchestrator; it is not a host
configuration schema. `config/codex/config.toml.example` and its role TOMLs are
optional native Codex configuration, with instructions in config/README.md.
Neither is loaded merely by importing this plugin. Host/admin policy and model
availability remain authoritative. In ChatGPT without per-agent overrides, use
the current available model and disclose that routing was not applied.
