---
name: content-writing
description: "Use SEO writing standards and the five-dimensional editorial quality rubric for natural brand voice and accurate content."
---


# Content writing and editorial quality

Read [the complete source framework](../seo-content-team/references/original-skills/content-writing/source.md)
and [runtime adaptations](../seo-content-team/references/runtime.md).
Evaluate natural brand voice (30%), specificity (25%), structure balance (20%),
SEO preservation (15%) and readability (10%). State measured versus judgment-based
dimensions. Improve clichés, formulaic transitions and vague examples without
inventing quotes, experiences or facts. Preserve meaningful Unicode; BOM/zero-width
characters do not establish AI authorship. Do not promise AI-detector evasion.
Use language-appropriate readability checks. Revise the top 3–5 issues and reassess
at most twice; if unresolved, report Needs Human Review with the actual issues.
A score of 70 is an editorial threshold, not evidence that all publication checks
passed. Follow the full role brief for long-form writing or detailed editing.
