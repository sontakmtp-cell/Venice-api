#!/usr/bin/env python3
"""Validate this skills-only plugin without installing it or calling providers."""
from pathlib import Path
import hashlib
import json
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]

def require(condition, message):
    if not condition:
        raise ValueError(message)

def contained(relative, base=ROOT):
    target = (base / relative).resolve()
    require(target.is_relative_to(ROOT.resolve()), f'Path escapes plugin: {relative}')
    require(target.exists(), f'Missing path: {target}')
    return target

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def validate():
    import yaml
    from jsonschema import Draft202012Validator, Draft7Validator

    results = []
    manifest = json.loads((ROOT / 'plugin.json').read_text())
    portable_schema = json.loads((ROOT / 'validation/plugin.schema.json').read_text())
    Draft202012Validator.check_schema(portable_schema)
    Draft202012Validator(portable_schema).validate(manifest)
    results.append('Portable manifest: official Agent Plugins 1.0 schema PASS')

    overlay = json.loads((ROOT / '.codex-plugin/plugin.json').read_text())
    for key in ['name', 'version', 'description', 'author', 'keywords']:
        require(overlay[key] == manifest[key], f'Manifest mismatch: {key}')
    require(ROOT.name == manifest['name'], 'Plugin directory does not match name')
    ui = manifest['extensions']['com.openai']['interface']
    require(ui == overlay['interface'], 'Interface mismatch')
    interface_fields = {
        'displayName', 'shortDescription', 'longDescription', 'developerName',
        'category', 'capabilities', 'websiteUrl', 'privacyPolicyUrl',
        'termsOfServiceUrl', 'defaultPrompt', 'brandColor', 'composerIcon',
        'logo', 'logoDark', 'screenshots',
    }
    require(set(ui) <= interface_fields, 'Unsupported interface field')
    for key in ['logo', 'composerIcon']:
        require(ui[key].startswith('./'), f'Asset path must start ./ : {key}')
        contained(ui[key])
    require(isinstance(ui['defaultPrompt'], list) and
            all(isinstance(p, str) and p.strip() for p in ui['defaultPrompt']),
            'Invalid default prompts')
    require(overlay['skills'] == './skills', 'Invalid Codex skill discovery path')
    require(not any(k in manifest for k in ['agents', 'skills', 'interface', 'expertType']),
            'Workbuddy or host-only fields in portable manifest')
    results.append('Codex overlay/interface synchronization and contained assets PASS')

    paths = sorted((ROOT / 'skills').rglob('SKILL.md'))
    require(len(paths) == 10, 'Expected 10 active skills')
    names = []
    for path in paths:
        text = path.read_text()
        require(text.startswith('---\n'), f'No frontmatter: {path}')
        header = re.split(r'^---\s*$', text, maxsplit=2, flags=re.M)[1]
        meta = yaml.safe_load(header)
        require(set(meta) == {'name', 'description'}, f'Unexpected skill fields: {path}')
        require(meta['name'] == path.parent.name, f'Name/directory mismatch: {path}')
        require(re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', meta['name']), 'Invalid skill name')
        require(0 < len(meta['name']) <= 64, 'Skill name exceeds limit')
        require(isinstance(meta['description'], str) and
                0 < len(meta['description']) <= 1024, f'Invalid description: {path}')
        names.append(meta['name'])
    require(len(names) == len(set(names)), 'Duplicate skill names')
    require('seo-content-team' in names, 'No orchestrator')
    results.append('10 skills: names, frontmatter, descriptions and discovery layout PASS')

    link_count = 0
    for path in ROOT.rglob('*.md'):
        if any(part in {'original-agents', 'original-skills', 'provenance'} for part in path.parts):
            continue
        text = re.sub(r'```.*?```', '', path.read_text(), flags=re.S)
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
            if re.match(r'[a-zA-Z][a-zA-Z0-9+.-]*:', link) or link.startswith('#'):
                continue
            contained(link.split('#')[0], path.parent)
            link_count += 1
    results.append(f'{link_count} active internal Markdown links resolve within plugin PASS')

    policy = json.loads((ROOT / 'config/model-policy.json').read_text())
    roles = policy['roles']
    require(len(roles) == 7 and 'seo-content-team-lead' in roles, 'Invalid roster')
    require(sum(r['model'] == 'gpt-6.1-sol' for r in roles.values()) == 4, 'Expected 4 Sol roles')
    require(sum(r['model'] == 'gpt-6-luna' for r in roles.values()) == 3, 'Expected 3 Luna roles')
    for role, data in roles.items():
        require(data['model'] in {'gpt-6.1-sol', 'gpt-6-luna'}, 'Invalid selected model')
        require(data['reasoning_effort'] in {'medium', 'high'}, 'Invalid reasoning effort')
        contained(f'skills/seo-content-team/references/original-agents/{role}.md')
        if role != 'seo-content-team-lead':
            require(role in names, f'Missing specialist entrypoint: {role}')
    contained(policy['escalation']['policy_reference'], ROOT / 'config')
    results.append('7-role model routing: 4 Sol / 3 Luna; escalation reference PASS')

    config_schema = json.loads((ROOT / 'validation/codex-config.schema.json').read_text())
    Draft7Validator.check_schema(config_schema)
    config_validator = Draft7Validator(config_schema)
    cfg_path = ROOT / 'config/codex/config.toml.example'
    cfg = tomllib.loads(cfg_path.read_text())
    config_validator.validate(cfg)
    require(cfg['model'] == roles['seo-content-team-lead']['model'], 'Lead config mismatch')
    actual_roles = {k: v for k, v in cfg['agents'].items() if isinstance(v, dict)}
    require(len(actual_roles) == 6, 'Expected 6 specialist Codex role entries')
    for native_role, entry in actual_roles.items():
        role = native_role.replace('_', '-')
        path = contained(entry['config_file'], cfg_path.parent)
        role_cfg = tomllib.loads(path.read_text())
        config_validator.validate(role_cfg)
        require(role_cfg['model'] == roles[role]['model'], f'Model mismatch: {role}')
        require(role_cfg['model_reasoning_effort'] == roles[role]['reasoning_effort'],
                f'Effort mismatch: {role}')
        require(len(role_cfg['developer_instructions']) > 3000, f'Incomplete role: {role}')
        require('Do not invent' in role_cfg['developer_instructions'], 'Missing runtime evidence guidance')
    results.append('Codex config sample and 6 role TOMLs: official schema + mapping PASS')

    provenance = json.loads((ROOT / 'provenance/files.json').read_text())
    counts = {'agents': 0, 'skills': 0, 'avatars': 0}
    for entry in provenance['files']:
        path = contained(entry['preserved_as'])
        require(digest(path) == entry['sha256'], f'Changed source copy: {path}')
        category = Path(entry['source']).parts[0]
        if category in counts:
            counts[category] += 1
    require(counts == {'agents': 7, 'skills': 3, 'avatars': 8}, f'Incomplete source: {counts}')
    results.append('Original 7 agents / 3 skills / 8 avatars and metadata: SHA-256 PASS')

    require(not (ROOT / '.codebuddy-plugin').exists(), 'Workbuddy manifest still active')
    for name in ['mcp.json', '.mcp.json', 'apps.json', '.env', 'node_modules']:
        require(not (ROOT / name).exists(), f'Unexpected runtime dependency or secret path: {name}')
    require(not (ROOT / 'skills/distribution-strategy').exists(), 'Invented source skill')
    results.append('No active Workbuddy manifest, invented missing skill or provider binding PASS')

    return {
        'status': 'PASS', 'checks': results, 'active_skills': names,
        'source_integrity_counts': counts,
        'schema_sha256': {name: digest(ROOT / 'validation' / name)
                          for name in ['plugin.schema.json', 'codex-config.schema.json']},
        'limitations': ['Host import/discovery not executed',
                        'Per-agent model execution not executed',
                        'Cloudflare/Vercel authentication and tool calls not executed'],
    }

if __name__ == '__main__':
    try:
        report = validate()
    except Exception as exc:
        print(f'FAIL: {type(exc).__name__}: {exc}', file=sys.stderr)
        sys.exit(1)
    if '--write-report' in sys.argv:
        (ROOT / 'validation/report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
