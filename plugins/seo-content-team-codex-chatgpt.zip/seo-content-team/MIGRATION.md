# Migration record

Source: user attachment `seo-content-team.zip`, Workbuddy/CodeBuddy manifest 1.0.0.
Target: skills-only portable Agent Plugins 1.0 + Codex compatibility overlay 2.0.0.

## Preserved

All seven original agent briefs, all three source SKILL.md files and all eight PNG
avatars are copied byte-for-byte. SHA-256 records are in provenance/files.json.
The professional roles and five-phase handoffs remain available in full.
Original source metadata/README are preserved under provenance/source/ as data.
Do not execute Workbuddy instructions there as host setup commands.

## Adapted

Workbuddy expertType/teamInfo/members/defaultInitPrompt and agent YAML presentation
fields are not injected into unsupported OpenAI manifest fields. Display metadata
maps to OpenAI interface; role identities map to discoverable skills and optional
Codex role configuration. maxTurns is not treated as a portable host setting.
TeamCreate/Agent/SendMessage become native tool dispatch with real runtime schemas,
or an honestly labeled sequential fallback. The lead stays in the invoking task.
Each role reads the full source methodology plus targeted runtime corrections.
Model routing uses gpt-6.1-sol and gpt-6-luna only; actual availability is host-specific.

## Source discrepancies and correctness changes

- README names differ from manifest/briefs; role IDs and manifest names are canonical.
- README lists distribution-strategy, but its directory is absent. No phantom skill
  was added; the converted package supplies only the three original frameworks.
- Fixed keyword density, length, counts and Flesch targets become adjustable,
  language-aware heuristics. Evidence and factual accuracy take priority.
- No fabricated keyword metrics, stories, quotes, customer results or conversion
  lifts. Source watermark/AI-detection claims are corrected in runtime guidance.
- Source scores remain available but cannot override missing publication checks.
- Provider integrations are optional capability guidance, not an OAuth grant or
  blanket production deployment request. No guessed endpoints or secret values.

## Sources used for packaging

- Agent Plugins schema: https://agent-plugins.org/schemas/1.0.0/plugin.schema.json
- Verified mirror: https://raw.githubusercontent.com/agentplugins/agent-plugins-spec/main/schemas/1.0.0/plugin.schema.json
- Codex manifest implementation: https://github.com/openai/codex/blob/main/codex-rs/core-plugins/src/manifest.rs
- Codex configuration schema: https://raw.githubusercontent.com/openai/codex/main/codex-rs/core/config.schema.json

The schema website and developers.openai.com were blocked by this environment's
egress policy; their official GitHub sources were retrieved without disabling TLS.
Captured schemas and hashes are included in validation/. OpenAI interface metadata
is checked against the observed loader field names; portable schema validation
does not define the semantics of vendor extensions. Actual host import/discovery
and provider/model operations remain unverified. No installed plugin was modified.
