# SEO Content Team — Codex / ChatGPT

Bản chuyển đổi 2.0.0 từ ZIP Workbuddy do người dùng cung cấp: 7 vai trò, 5 giai
đoạn, 3 framework hỗ trợ. Tài liệu chuyên môn gốc được giữ nguyên; entrypoint mới
dùng công cụ thực tế của host, có chính sách chọn GPT-6 Luna / GPT-6.1 Sol.

## Cài đặt và gọi

Giải nén ZIP, chọn thư mục `seo-content-team/` qua quy trình cài/import plugin
cục bộ hoặc marketplace mà phiên bản Codex của bạn hỗ trợ. Với ChatGPT, dùng
quy trình import/tạo plugin nếu tài khoản và host có cung cấp. Không có lệnh CLI
hay menu cài đặt được giả định. Gói này chưa được cài hay phát hành từ cuộc chat.

Sau khi cài, kiểm tra danh sách skill có `seo-content-team:seo-content-team`.
Gọi `$seo-content-team` hoặc chọn entrypoint SEO Content Team trong danh sách skill.
Các chuyên gia có skill riêng; định danh đầy đủ thường có dạng
`seo-content-team:keyword-researcher`. Cú pháp chính xác phụ thuộc host.

Nếu giao diện ChatGPT không có import plugin, việc tải ZIP lên chat chỉ cung cấp
tài liệu tham khảo, không cài plugin. Đọc SKILL.md và các references có thể chạy
quy trình tuần tự trong chat, nhưng không tự tạo agent hay chọn model khác.

Ví dụ yêu cầu:

- “Dùng SEO Content Team nghiên cứu từ khóa cho [chủ đề], thị trường Việt Nam.”
- “Viết bài SEO từ brief này; giữ giọng thương hiệu, dẫn nguồn và kiểm tra liên kết.”
- “Tối ưu bài hiện có bằng SEO, biên tập và chiến lược liên kết.”
- “Phân tích landing page này và thiết kế A/B test cho CTA.”

## Chuyên gia và mô hình

| Vai trò | Mô hình mặc định |
|---|---|
| Trưởng nhóm Sou | GPT-6.1 Sol, khi được chọn cho cuộc hội thoại |
| Nghiên cứu Guan | GPT-6.1 Sol |
| Viết bài Wen | GPT-6.1 Sol |
| Tối ưu SEO Ou | GPT-6 Luna |
| Biên tập Ai | GPT-6 Luna |
| CRO Lv | GPT-6.1 Sol |
| Liên kết Lian | GPT-6 Luna |

Luna có thể chuyển nhiệm vụ phức tạp sang Sol theo model-policy.md. Cấu hình
Markdown/JSON không ép model; host phải hỗ trợ override và tài khoản phải có quyền
truy cập. [Cấu hình Codex tùy chọn](config/README.md) gồm role TOML đã kiểm tra schema.

## Cloudflare và Vercel

Cho phép chuyên gia dùng hai plugin khi tác vụ cần và công cụ đã kết nối. Chúng là
tích hợp tùy chọn, cần cài/kết nối riêng; gói không chứa credential hay MCP endpoint
tự đoán. Xem [chính sách tích hợp](skills/seo-content-team/references/integrations.md).
Chưa có kết nối hoặc kiểm thử provider trong phiên chuyển đổi này. Bản chuyển đổi
không triển khai website, không đổi DNS và không xuất bản nội dung.

## Cấu trúc

- `plugin.json`: manifest portable Agent Plugins 1.0.
- `.codex-plugin/plugin.json`: manifest tương thích Codex, đồng bộ tên/version/UI.
- `skills/`: 10 entrypoint: trưởng nhóm, 6 chuyên gia, 3 framework.
- `skills/seo-content-team/references/`: runtime, model policy, integrations và
  toàn bộ 7 agent + 3 skill gốc.
- `config/`: policy JSON và cấu hình Codex tùy chọn, không tự kích hoạt.
- `avatars/`: 8 ảnh gốc.
- `scripts/validate.py`: kiểm tra cấu trúc, liên kết, model mapping và provenance.
- `validation/`: schema đối chiếu và báo cáo kiểm tra tĩnh.

Không cần npm/pip/MCP server để chạy phương pháp của gói. Chỉ trình kiểm tra phát
triển tùy chọn cần Python 3.11+, PyYAML và jsonschema nếu kiểm tra schema đầy đủ.
Plugin Creator không khả dụng trong phiên tạo gói; bản chuyển đổi được thực hiện
trực tiếp theo hướng dẫn đóng gói và schema chính thức. Xem MIGRATION.md.

## Giới hạn đã xác minh

Đã kiểm tra manifest, JSON/TOML, entrypoint, đường dẫn nội bộ, bảng mô hình và tính
nguyên vẹn tài liệu/ảnh nguồn. Chưa kiểm thử cài đặt trong host, gọi model cho từng
agent, kết nối Cloudflare/Vercel hoặc xuất bản. Kiểm tra tĩnh không thay thế chạy
thực tế trên phiên bản host/tài khoản của bạn. Nếu host không có agent native,
fallback được ghi rõ là các lượt xử lý tuần tự, không giả lập một đội độc lập.
